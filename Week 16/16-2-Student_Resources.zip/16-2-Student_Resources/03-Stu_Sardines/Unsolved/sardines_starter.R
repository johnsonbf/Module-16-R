sardines <- read.csv(file="../Resources/sardines.csv")

# Calculate the population mean for Sardine Vertebrae in Alaska.
# Hint: use the subset() function to get only the data for Alaska.

# Calculate the population mean for Sardine Vertebrae in San Diego.
# Hint: use the subset() function to get only the data for San Diego.

# Calculate Independent (Two Sample) T-Test
