# Hair Color vs. Pain Threshold ANOVA

## Instructions

* Perform a one-way ANOVA test to determine if there are any significant differences in Hair Color vs. Pain Threshold.

* Create a Boxplot to show the distribution of pain tolerances for each hair color.

- - -

© 2021 Trilogy Education Services, a 2U, Inc. brand.  All Rights Reserved.
