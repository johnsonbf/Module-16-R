# Read in the CSV file. 
hair <- read.csv(file="../Resources/hair.csv")

#  Plot the data using ggplot

# Determine the p-value using ANOVA