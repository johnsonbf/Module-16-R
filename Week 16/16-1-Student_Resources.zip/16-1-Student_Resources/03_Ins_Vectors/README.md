# Vectors and Pipes

## Instructions 

* Code along with the instructor using the [vectors_starter.R](Unsolved/vectors_starter.R) file to apply functions to vectors, use the pip operator, and get statistical summaries.

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.